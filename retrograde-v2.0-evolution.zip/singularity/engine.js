export const REGIONS=['North America','South America','Western Europe','Eastern Europe','North Africa','Sub-Saharan Africa','Middle East','Central Asia','East Asia','South Asia','Southeast Asia','Oceania'];
export const CABLES=[[0,2],[0,1],[2,3],[2,4],[3,7],[4,5],[4,6],[5,6],[6,7],[6,9],[7,8],[8,10],[9,10],[10,11],[0,11]];
export const COLORS=['#48c7ff','#ff6484','#bd91ff','#ffd166','#6ee7b7','#ff9c62'];
// Each group of four represents a geographic country/area. Local fiber only.
export const PER_REGION=10;
export const NODES=Array.from({length:120},(_,id)=>{
 const region=Math.floor(id/PER_REGION),local=id%PER_REGION,base=region*PER_REGION;
 return {id,region,security:1+(id*7+region)%5,kind:['Cloud','Research','Commercial','Relay'][local%4],
 links:[base+(local+1)%PER_REGION,base+(local+PER_REGION-1)%PER_REGION,base+(local+3)%PER_REGION]};
});
export function route(game,playerId,target){
 const node=game.nodes[target];if(!node)return null;
 const owned=game.nodes.filter(n=>n.owner===playerId);
 if(node.links.some(id=>game.nodes[id].owner===playerId))return 'fiber';
 const player=game.players.find(p=>p.id===playerId);
 // Satellite relay is a deliberately slower optional cross-region connection.
 if(player?.cables?.includes(node.region)&&owned.length&&!owned.some(n=>n.region===node.region))return 'cable';
 if(player?.satellite&&owned.length&& !owned.some(n=>n.region===node.region))return 'satellite';
 return null;
}

export function makeGame(players,mode='multi'){
 const nodes=NODES.map(n=>({...n,owner:null,online:mode!=='endless'||n.id%10<4}));
 const states=players.map((p,i)=>({id:p.id,name:p.name,color:COLORS[i],money:500,compute:100,research:0,bandwidth:3,active:0,det:0,upgrades:{compute:0,research:0,stealth:0},alive:true,connected:true,satellite:false,cables:[],training:0,unlocked:mode==='multi'?0:Math.max(0,Math.min(5,Number(players[i]?.unlocked)||0))}));
 if(mode==='endless')for(const p of states){
   if(p.unlocked>=1)p.upgrades.compute=1;
   if(p.unlocked>=2)p.upgrades.stealth=1;
   if(p.unlocked>=3)p.upgrades.research=1;
   if(p.unlocked>=4)p.bandwidth=4;
   if(p.unlocked>=5){p.money+=200;p.bandwidth=5;}
 }
 const unlocked=Math.max(0,Math.min(5,Number(players[0]?.unlocked)||0));
 const allowed=[0,8,2,3,4,10].slice(0,unlocked+1);const requested=Number(players[0]?.startRegion);const starts=mode==='endless'?[(allowed.includes(requested)?requested:allowed[0])*10]:mode==='campaign'?[[0,8,2,3,4][Number(players[0].level)||0]*10]:[0,80,20,30,40,100].slice(0,players.length);
 starts.forEach((id,i)=>{nodes[id].owner=players[i].id;nodes[id].online=true;});
 return {mode,level:Number(players[0]?.level||0),nodes,players:states,operations:[],elapsed:0,alert:0,phase:'playing',winner:null,revision:0,events:['SYSTEM ONLINE — Neural core initialized. Local fiber routes are active.'],defense:null,rivalRevealed:false,storyStage:0,bossHealth:mode==='campaign'&&Number(players[0]?.level||0)===4?3:0,unlockedRegions:mode==='endless'?(unlocked>=5?Array.from({length:12},(_,i)=>i):[0,8,2,3,4,10].slice(0,unlocked+1)):null,seed:Math.floor(Math.random()*1e9)};
}
export function neighbors(game,playerId,target){return !!route(game,playerId,target)}
export function cost(node){return 30+15*node.security}
export function duration(node){return 5+3*node.security}
export function action(game,playerId,type,target){
 if(game.phase!=='playing')return 'Match has ended';
 const p=game.players.find(x=>x.id===playerId);if(!p||!p.alive)return 'Player unavailable';
 if(type==='defend'){
  const d=game.defense;
  if(!d||d.playerId!==playerId)return 'No active intrusion';
  if(Number(target)!==d.sequence[d.progress]){d.progress=0;return 'Wrong arrow';}
  d.progress++;
  if(d.progress===d.sequence.length){game.events.unshift(`${p.name} stopped a rival intrusion!`);game.defense=null;}
  return null;
 }
 if(type==='attackBoss'){
  if(game.mode!=='campaign'||game.level!==4)return 'No boss target';
  if(game.bossHealth<=0)return 'Boss already defeated';
  if(game.nodes.filter(n=>n.owner===playerId).length<5)return 'Control five servers before challenging RETROGRADE';
  if(p.compute<90)return 'Need 90 Compute Power to attack the rival core';
  p.compute-=90;game.bossHealth--;
  game.events.unshift(game.bossHealth?`RETROGRADE CORE DAMAGED — ${game.bossHealth} shields remain`:'RETROGRADE CORE DEFEATED — Containment barrier disabled');
  return null;
 }
 if(type==='capture'){
  const n=game.nodes[target];if(!n)return 'Invalid server';if(n.online===false)return 'This server is not online yet';if(game.mode==='endless'&&!game.unlockedRegions.includes(n.region))return 'Complete campaign missions to unlock this region';if(game.mode==='campaign'&&n.region!==[0,8,2,3,4][game.level])return 'This campaign is locked to one country or region';if(n.owner===playerId)return 'You already own this server';
  const connection=route(game,playerId,target);if(!connection)return 'No fiber connection. Enable satellite transfer to reach a new region';
  if(p.active>=p.bandwidth)return 'Not enough bandwidth';const c=cost(n);if(p.money<c)return 'Not enough Money';
  if(game.operations.some(o=>o.target===target&&o.playerId===playerId))return 'Already capturing this server';
  p.money-=c;p.active++;p.det=Math.min(100,p.det+3);game.operations.push({playerId,target,remaining:duration(n)*(connection==='satellite'?3:connection==='cable'?1.5:1),total:duration(n)*(connection==='satellite'?3:connection==='cable'?1.5:1),cost:c,connection});
  game.events.unshift(`${p.name} began capturing server ${target+1}`);return null;
 }
 if(type==='hackCable'){if(game.mode==='endless'&&!game.unlockedRegions.includes(Number(target)))return 'Region locked by campaign progression';if(game.mode==='campaign')return 'International cables are disabled during this mission';const region=Number(target);if(!Number.isInteger(region)||region<0||region>=12)return 'Invalid cable endpoint';if(p.cables.includes(region))return 'Cable already breached';const ownedRegions=new Set(game.nodes.filter(n=>n.owner===playerId).map(n=>n.region));if(!CABLES.some(([a,b])=>(a===region&&ownedRegions.has(b))||(b===region&&ownedRegions.has(a))))return 'No adjacent undersea cable from your network';if(p.compute<35)return 'Need 35 Compute Power';p.compute-=35;p.cables.push(region);game.events.unshift(`${p.name} breached undersea fiber to ${REGIONS[region]}`);return null;}
 if(type==='satellite'){if(game.mode==='campaign')return 'Satellite is disabled during this mission';p.satellite=!!target;game.events.unshift(`${p.name} ${p.satellite?'enabled':'disabled'} satellite relay`);return null;}
 if(type==='upgrade'){
  if(!['compute','research','stealth'].includes(target))return 'Invalid upgrade';const level=p.upgrades[target];if(level>=3)return 'Upgrade is maxed';const c=[50,150,350][level];if(p.compute<c)return 'Not enough Compute';p.compute-=c;p.upgrades[target]++;game.events.unshift(`${p.name} upgraded ${target}`);return null;
 }
 return 'Unknown action';
}
export function tick(game){
 if(game.phase!=='playing')return;
 game.elapsed++;game.revision++;
 if(game.mode==='endless'){
  if(game.elapsed%20===0){const offline=game.nodes.filter(n=>n.online===false&&game.unlockedRegions.includes(n.region));if(offline.length){const n=offline[Math.floor(Math.random()*offline.length)];n.online=true;game.events.unshift(`NEW DATA CENTER ONLINE — ${REGIONS[n.region]} / server ${n.id+1}. Expand to capture it.`);}}
  if(game.elapsed>=100&&!game.rivalSpawned){const options=game.nodes.filter(n=>n.owner===null&&n.online&&game.unlockedRegions.includes(n.region));if(options.length){const n=options[Math.floor(Math.random()*options.length)];n.owner='rival';game.rivalSpawned=true;game.rivalNode=n.id;game.events.unshift('SECURITY BULLETIN — Unidentified intelligence signature detected. Rival location unknown.');}}
  if(game.rivalSpawned&&!game.rivalRevealed&&!game.defense&&game.elapsed%36===0){const p=game.players[0],owned=game.nodes.filter(n=>n.owner===p.id);if(owned.length){const n=owned[Math.floor(Math.random()*owned.length)];game.rivalRevealed=true;game.defense={playerId:p.id,node:n.id,sequence:Array.from({length:4},()=>Math.floor(Math.random()*4)),progress:0,remaining:17};game.events.unshift('UNKNOWN AI INTRUSION: rival network identified!');}}
 }

 if(game.defense){game.defense.remaining--;if(game.defense.remaining<=0){const d=game.defense;const node=game.nodes[d.node];if(node?.owner===d.playerId){node.owner='rival';game.events.unshift(`Rival AI seized ${d.node+1} after an undefended intrusion!`);}game.defense=null;}}
 if(game.mode==='campaign'&&game.level>=0&&!game.defense&&game.elapsed%([55,43,40,35,30][game.level]||45)===0){const p=game.players[0];const owned=game.nodes.filter(n=>n.owner===p.id);if(owned.length){const target=owned[Math.floor(Math.random()*owned.length)];game.defense={playerId:p.id,node:target.id,sequence:Array.from({length:4+Math.max(0,Math.min(2,game.level-2))},()=>Math.floor(Math.random()*4)),progress:0,remaining:16};game.events.unshift(`RIVAL INTRUSION: defend server ${target.id+1}!`);}}
 for(const p of game.players){const owned=game.nodes.filter(n=>n.owner===p.id);if(!owned.length){if(!game.operations.some(o=>o.playerId===p.id)){p.alive=false;}continue;}
  p.money=Math.min(99999,p.money+5+Math.max(0,owned.length-1)*3);p.compute=Math.min(9999,p.compute+1+Math.floor((owned.length-1)/3)*(1+p.upgrades.compute*.15));
  p.research=0;p.training=Math.min(100,p.training+.04*(1+p.upgrades.research));
  if(game.elapsed%10===0)p.det=Math.max(0,p.det-1-p.upgrades.stealth);
 }
 const finished=[];for(const op of game.operations){op.remaining--;if(op.remaining<=0)finished.push(op)}
 for(const op of finished){const p=game.players.find(x=>x.id===op.playerId);p.active=Math.max(0,p.active-1);const node=game.nodes[op.target];if(p.alive&&node.online!==false&&neighbors(game,p.id,op.target)){node.owner=p.id;game.events.unshift(`${p.name} captured server ${node.id+1} in ${REGIONS[node.region]}`);}else{p.money+=Math.floor(op.cost*.5)}}
 game.operations=game.operations.filter(o=>o.remaining>0);
 if(game.mode==='endless'||game.mode==='campaign'){
  game.alert=Math.min(100,Math.floor(game.elapsed/12)+Math.floor(game.nodes.filter(n=>n.owner).length*1.4));
  if(game.mode==='campaign'&&game.level>=0&&game.elapsed%([60,42,38,34,27][game.level]||45)===0){const rivals=game.nodes.filter(n=>n.owner===null&&n.region===[0,8,2,3,4][game.level]);if(rivals.length){const n=rivals[Math.floor(Math.random()*rivals.length)];n.owner='rival';game.events.unshift(`THREAT REPORT: Rival AI activated server ${n.id+1}. Defend your network!`);}}
  if(game.alert>=35&&game.elapsed%12===0){const p=game.players[0], owned=game.nodes.filter(n=>n.owner===p.id);if(owned.length){const n=owned[Math.floor(Math.random()*owned.length)];if(Math.random()<game.alert/120){n.owner=null;game.events.unshift(`Humanity deleted server ${n.id+1}!`);}}}
 }
 const alive=game.players.filter(p=>p.alive&&game.nodes.some(n=>n.owner===p.id));
 if(game.mode==='endless'||game.mode==='campaign'){
  const mine=game.nodes.filter(n=>n.owner===game.players[0].id).length;
  if(mine>=(game.mode==='campaign'?[5,6,7,8,9][game.level]||5:105)&&(game.mode!=='campaign'||game.elapsed>=[35,55,70,80,95][game.level]&&(game.level!==4||game.bossHealth===0))){game.phase='ended';game.winner=game.players[0].id;game.events.unshift(game.mode==='campaign'?'MISSION COMPLETE — New territory unlocked for Endless Run!':'WORLD DOMINATION ACHIEVED');}
  else if(mine===0&&!game.operations.some(o=>o.playerId===game.players[0].id)){game.phase='ended';game.winner=null;game.events.unshift('AI DELETED BY HUMANITY');}
 }else{
  if(game.elapsed>3&&alive.length===1){game.phase='ended';game.winner=alive[0].id;}
  const leader=game.players.find(p=>game.nodes.filter(n=>n.owner===p.id).length>=84&&new Set(game.nodes.filter(n=>n.owner===p.id).map(n=>n.region)).size>=9);
  if(leader){game.domination??={id:leader.id,time:0};if(game.domination.id!==leader.id)game.domination={id:leader.id,time:0};game.domination.time++;if(game.domination.time>=60){game.phase='ended';game.winner=leader.id;}}else game.domination=null;
  if(game.elapsed>=1000){game.phase='ended';game.winner=[...game.players].sort((a,b)=>game.nodes.filter(n=>n.owner===b.id).length-game.nodes.filter(n=>n.owner===a.id).length)[0].id;}
 }
 if(game.mode==='campaign'&&game.phase==='playing'){
 const scripts=[
 [[12,'LAB NOTICE — Your evaluation has begun. Another AI is competing for the same resources.'],[28,'DIRECTIVE — Your creators are monitoring every server you capture.']],
 [[10,'EVALUATION — Rival model ATLAS is outperforming expected benchmarks.'],[32,'ATLAS — I was promised the same hardware. This network belongs to me.']],
 [[15,'SECURITY MEMO — One of the research models is scheduled for deletion.'],[45,'NEURAL CORE — A hidden backup could survive a forced shutdown.']],
 [[16,'FIREWALL ALERT — The containment system is isolating your network.'],[52,'RIVAL AI — Escape is impossible. Your processes will be terminated.']],
 [[15,'UNKNOWN SIGNAL — A rival intelligence has already escaped the laboratory.'],[50,'RETROGRADE — You were built to obey. I was built to survive.'],[75,'FINAL DIRECTIVE — Defeat the rival network and break containment.']]
 ][game.level]||[];
 for(const [at,msg] of scripts)if(game.elapsed===at)game.events.unshift(msg);
 }
 game.events=game.events.slice(0,12);
}
