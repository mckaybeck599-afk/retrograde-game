import http from 'node:http';import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';import {makeGame,action,tick} from './engine.js';
const root=path.join(path.dirname(fileURLToPath(import.meta.url)),'public');const rooms=new Map();const clients=new Map();const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data))};
const token=()=>crypto.randomBytes(16).toString('hex');const code=()=>crypto.randomBytes(3).toString('hex').toUpperCase();
const safeRoom=r=>({code:r.code,host:r.host,players:r.players.map(({id,name,ready})=>({id,name,ready})),game:r.game});
function broadcast(r){for(const res of clients.get(r.code)||[]){try{res.write(`data: ${JSON.stringify(safeRoom(r))}\n\n`)}catch{}}}
const server=http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost');if(req.method==='POST'&&url.pathname.startsWith('/api/')){
  let body='';for await(const chunk of req){body+=chunk;if(body.length>10000)return json(res,413,{error:'Request too large'})}let data;try{data=JSON.parse(body)}catch{return json(res,400,{error:'Invalid JSON'})}
  const name=String(data.name||'AI').trim().slice(0,20).replace(/[<>]/g,'')||'AI';let r=rooms.get(String(data.code||'').toUpperCase());let p=r?.players.find(x=>x.token===data.token);
  if(url.pathname==='/api/create'){
   let c;do{c=code()}while(rooms.has(c));const id=token();const t=token();r={code:c,host:id,players:[{id,token:t,name,ready:false}],game:null,created:Date.now()};rooms.set(c,r);return json(res,200,{code:c,token:t,id});
  }
  if(url.pathname==='/api/join'){
   if(!r)return json(res,404,{error:'Room not found'});if(r.game)return json(res,409,{error:'Match already started'});if(r.players.length>=6)return json(res,409,{error:'Room is full'});
   const id=token(),t=token();r.players.push({id,token:t,name,ready:false});broadcast(r);return json(res,200,{code:r.code,token:t,id});
  }
  if(url.pathname==='/api/endless'||url.pathname==='/api/campaign'){
   const id=token(),t=token();let c;do{c=code()}while(rooms.has(c));r={code:c,host:id,players:[{id,token:t,name,ready:true}],game:null,created:Date.now()};r.players[0].level=Math.max(0,Math.min(4,Number(data.level)||0));r.players[0].unlocked=Math.max(0,Math.min(5,Number(data.unlocked)||0));r.players[0].startRegion=Number(data.startRegion);r.game=makeGame(r.players,url.pathname==='/api/campaign'?'campaign':'endless');rooms.set(c,r);return json(res,200,{code:c,token:t,id});
  }
  if(!r||!p)return json(res,403,{error:'Invalid session'});
  if(url.pathname==='/api/leave'){r.players=r.players.filter(x=>x.id!==p.id);if(r.host===p.id)r.host=r.players[0]?.id||null;if(!r.players.length){rooms.delete(r.code);for(const stream of clients.get(r.code)||[])stream.end();clients.delete(r.code)}else broadcast(r);return json(res,200,{ok:true})}
  if(url.pathname==='/api/ready'){if(r.game)return json(res,409,{error:'Already started'});p.ready=!!data.ready;broadcast(r);return json(res,200,{ok:true})}
  if(url.pathname==='/api/start'){if(r.host!==p.id)return json(res,403,{error:'Only host can start'});if(r.game)return json(res,409,{error:'Already started'});if(r.players.length<2||!r.players.every(x=>x.ready))return json(res,400,{error:'Need at least two ready players'});r.game=makeGame(r.players);broadcast(r);return json(res,200,{ok:true})}
  if(url.pathname==='/api/action'){if(!r.game)return json(res,409,{error:'Match not started'});const error=action(r.game,p.id,data.type,data.target);if(error)return json(res,400,{error});r.game.revision++;broadcast(r);return json(res,200,{ok:true})}
  return json(res,404,{error:'Unknown endpoint'});
 }
 if(req.method==='GET'&&url.pathname==='/api/stream'){
  const r=rooms.get(String(url.searchParams.get('code')||'').toUpperCase());if(!r||!r.players.some(p=>p.token===url.searchParams.get('token')))return json(res,403,{error:'Invalid session'});
  res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','Access-Control-Allow-Origin':'*'});if(!clients.has(r.code))clients.set(r.code,new Set());clients.get(r.code).add(res);res.write(`data: ${JSON.stringify(safeRoom(r))}\n\n`);req.on('close',()=>clients.get(r.code)?.delete(res));return;
 }
 const file=url.pathname==='/'?'index.html':url.pathname.slice(1);if(!['index.html','app.js','map-data.js','style.css'].includes(file))return json(res,404,{error:'Not found'});
 fs.readFile(path.join(root,file),(err,buf)=>{if(err)return json(res,404,{error:'Not found'});res.writeHead(200,{'Content-Type':file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':'text/html'});res.end(buf)});
});
setInterval(()=>{for(const r of rooms.values()){if(r.game?.phase==='playing'){tick(r.game);broadcast(r)}}},1000);
setInterval(()=>{for(const [c,r] of rooms)if(Date.now()-r.created>3*60*60*1000){rooms.delete(c);for(const res of clients.get(c)||[])res.end();clients.delete(c)}},60000);
const port=Number(process.env.PORT||3000);server.listen(port,'0.0.0.0',()=>console.log(`RETROGRADE running at http://localhost:${port}`));
