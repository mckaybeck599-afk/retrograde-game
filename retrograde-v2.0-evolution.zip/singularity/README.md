# RETROGRADE v2.0 — Evolution

Playable local browser strategy game. Requires Node.js 18+.

## Run

Open a terminal in the `singularity` directory, then run:

```bash
npm start
```

Open http://localhost:3000 in your browser. If an older version is running, stop it with Ctrl+C first. Use Ctrl+Shift+R to clear cached JavaScript/CSS.

## What's new

- 120 server nodes across 12 geographic regions; 10 per region.
- Dark blue translucent ocean treatment, animated cyan undersea cable pulses, and small moving satellites in Endless Run.
- Two hacking games: click-to-rotate circuit tiles and a reaction timing lock. Cable breaches also use a circuit puzzle.
- Five story missions with scripted messages, increasing objectives, and a three-shield final boss.
- Campaign progress unlocks new Endless Run deployment regions and five gameplay bonuses.
- A CSS 3D neural hologram with seamless rotation, animated code particles, and customizable color.
- Gold owned servers, red rival servers, server-rack neutral markers, and colored geographic regions.

## Controls

Click a country to zoom; scroll down over the map to return to the world view (Endless Run). Click a server to inspect it, complete a hacking puzzle, then capture it with Money. Use Compute Power for AI upgrades and boss attacks. Use the arrow keys to defend against rival intrusion alerts.

## Notes

This is a playable prototype, not a completed commercial game. The 120 server sites are approximations near major data-center markets, not verified physical facilities. Fiber routes are stylized, not actual cable geography. The 3D Neural Core uses CSS perspective, not WebGL. Multiplayer is a local Node server; hosting on a public URL requires deployment. Progress and settings are saved in browser storage.

## Tests

```bash
npm test
```
