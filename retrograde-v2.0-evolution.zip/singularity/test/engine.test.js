import test from 'node:test';import assert from 'node:assert/strict';import {makeGame,action,tick,NODES,cost} from '../engine.js';
const players=[{id:'a',name:'Alpha'},{id:'b',name:'Beta'}];
test('120 servers and 12 regions',()=>{assert.equal(NODES.length,120);assert.equal(new Set(NODES.map(n=>n.region)).size,12)});
test('players spawn on different servers',()=>{const g=makeGame(players);assert.equal(g.nodes.filter(n=>n.owner).length,2);assert.notEqual(g.nodes.find(n=>n.owner==='a').id,g.nodes.find(n=>n.owner==='b').id)});
test('capture costs compute and completes',()=>{const g=makeGame(players);const id=NODES[0].links[0];assert.equal(action(g,'a','capture',id),null);assert.equal(g.players[0].money,500-cost(g.nodes[id]));for(let i=0;i<25;i++)tick(g);assert.equal(g.nodes[id].owner,'a')});
test('cannot capture nonadjacent servers',()=>{const g=makeGame(players);assert.match(action(g,'a','capture',85),/connect/)});
test('upgrades require compute',()=>{const g=makeGame(players);g.players[0].compute=0;assert.match(action(g,'a','upgrade','compute'),/Compute/);g.players[0].compute=50;assert.equal(action(g,'a','upgrade','compute'),null);assert.equal(g.players[0].upgrades.compute,1)});
test('endless starts with one server',()=>{const g=makeGame([players[0]],'endless');assert.equal(g.nodes.filter(n=>n.owner).length,1)});

test('fiber links stay within their region',()=>{
 for(const node of NODES)for(const id of node.links)assert.equal(NODES[id].region,node.region);
});

test('satellite relay opens a new region and takes three times as long',()=>{
 const game=makeGame([{id:'p1',name:'Player',unlocked:5}],'endless');
 const start=game.nodes.find(n=>n.owner==='p1');
 const target=game.nodes.find(n=>n.region!==start.region&&game.unlockedRegions.includes(n.region));target.online=true;
 assert.equal(action(game,'p1','capture',target.id)!==null,true);
 assert.equal(action(game,'p1','satellite',true),null);
 assert.equal(action(game,'p1','capture',target.id),null);
 const op=game.operations.find(o=>o.target===target.id);
 assert.equal(op.total,3*(5+3*target.security));
 assert.equal(op.connection,'satellite');
});


test('fiber cable breach requires adjacent region and compute, then opens capture',()=>{
 const g=makeGame([{id:'a',name:'Alpha',unlocked:5}],'endless');
 g.nodes.forEach(n=>{n.owner=null;n.online=true});g.nodes[0].owner='a';
 assert.match(action(g,'a','hackCable',7),/adjacent/);
 assert.equal(action(g,'a','hackCable',2),null);
 assert.equal(g.players[0].compute,65);
 assert.equal(action(g,'a','capture',20),null);
 assert.equal(g.operations[0].connection,'cable');
});
test('training advances and late campaign introduces rival AI',()=>{
 const g=makeGame([{id:'a',name:'Alpha',level:3}],'campaign');
 for(let i=0;i<35;i++)tick(g);
 assert.ok(g.players[0].training>0);
 assert.ok(g.nodes.some(n=>n.owner==='rival'));
});

test('rival intrusion is stopped by correct arrow sequence',()=>{const g=makeGame([{id:'a',name:'Alpha',level:3}],'campaign');g.defense={playerId:'a',node:24,sequence:[0,1,2],progress:0,remaining:15};assert.equal(action(g,'a','defend',0),null);assert.equal(g.defense.progress,1);assert.equal(action(g,'a','defend',2),'Wrong arrow');assert.equal(g.defense.progress,0);for(const k of [0,1,2])assert.equal(action(g,'a','defend',k),null);assert.equal(g.defense,null)});
test('unanswered intrusion loses the server',()=>{const g=makeGame([{id:'a',name:'Alpha',level:3}],'campaign');g.nodes[24].owner='a';g.defense={playerId:'a',node:24,sequence:[0],progress:0,remaining:1};tick(g);assert.equal(g.nodes[24].owner,'rival')});

test('campaign stays in one region and blocks satellite and international fiber',()=>{const g=makeGame([{id:'a',name:'Alpha',level:0}],'campaign');assert.match(action(g,'a','capture',80),/locked/);assert.match(action(g,'a','satellite',true),/disabled/);assert.match(action(g,'a','hackCable',2),/disabled/);assert.equal(action(g,'a','capture',1),null);});

test('endless starts with only the first region unlocked',()=>{const g=makeGame([{id:'a',name:'A'}],'endless');assert.deepEqual(g.unlockedRegions,[0]);assert.match(action(g,'a','hackCable',2),/locked/)});
test('new servers appear over time in endless',()=>{const g=makeGame([{id:'a',name:'A'}],'endless');const before=g.nodes.filter(n=>n.online).length;for(let i=0;i<28;i++)tick(g);assert.ok(g.nodes.filter(n=>n.online).length>before)});

test('campaign boss requires compute and five servers',()=>{const g=makeGame([{id:'a',name:'A',level:4}],'campaign');assert.match(action(g,'a','attackBoss'),/five servers/);for(let i=41;i<45;i++)g.nodes[i].owner='a';g.players[0].compute=270;for(let i=0;i<3;i++)assert.equal(action(g,'a','attackBoss'),null);assert.equal(g.bossHealth,0)});
test('campaign perks are earned in endless but not multiplayer',()=>{const g=makeGame([{id:'a',name:'A',unlocked:5}],'endless');assert.equal(g.players[0].bandwidth,5);const m=makeGame([{id:'a',name:'A',unlocked:5},{id:'b',name:'B'}],'multi');assert.equal(m.players[0].bandwidth,3)});
test('120 nodes spread across 12 groups of ten',()=>{for(let r=0;r<12;r++)assert.equal(NODES.filter(n=>n.region===r).length,10)});
